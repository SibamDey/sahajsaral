import React from 'react'
import { Routes, Route } from "react-router-dom";
import EditAchievement from "../Achievement/EditAchievement";
import AddAchievement from '../Achievement/AddAchievement';
import AchievementList from '../Achievement/AchievementList';
import AchievementDetails from '../Achievement/AchievementDetails';
import { useLocation } from 'react-router-dom';
import { Location } from '../Achievement/LocationContext';
import Achivementpdf from '../Achievement/Achivementpdf';
import AchievementView from '../Achievement/AchievementView';


const Index = () => {
  const location = useLocation()
  return (
    <Location.Provider value={location}>
      <Routes>
        <Route path="/" element={<AchievementList />} />
        <Route path="/add-achievement" element={<AddAchievement />} />
        <Route path="/achievement-details" element={<AchievementDetails />} />
        <Route path="/edit-achievement" element={<EditAchievement />} />
        <Route path="/achivementpdf" element={<Achivementpdf />} />
        <Route path="/AchievementView" element={<AchievementView />} />

        

        
      </Routes>
    </Location.Provider>
  )
}

export default Index
