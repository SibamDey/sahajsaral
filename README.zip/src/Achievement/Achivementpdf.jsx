import React, { useState,useEffect } from 'react'
import logo from '.././assets/img/biswa.png'
import { Navigate } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import stateStore from "../Achievement/Zustand";
import { getSchemeList, getCategoryList, getThemeList } from "../AchievementService"

const Achivementpdf = () => {
    const { value, setValue } = stateStore();
    console.log(value, "vavavava")
    const [print, setPrint] = useState(false)
    const [getSchemeDataList, setSchemeDataList] = useState([]);
    const [getCategoryDataList, setCategoryDataList] = useState([]);
    const [getThemeDataList, setThemeDataList] = useState([]);

    const navigate = useNavigate();

    const optionsData = [
        { label: 'State wide', value: 'S' },
        { label: 'District Level', value: 'D' },
        { label: 'Block', value: 'B' },
        { label: 'GP Level', value: 'GP' },
        // Add more options as needed
      ];

    useEffect(() => {
        getSchemeListData();
        getCategoryListData();
        getThemeListData();
      }, []);


      async function getSchemeListData() {
        getSchemeList().then(function (result) {
          const response = result?.data;
          console.log(response, "resresres")
          setSchemeDataList(response);
        });
      }
    
      async function getCategoryListData() {
        getCategoryList().then(function (result) {
          const response = result?.data;
          console.log(response, "resresres")
          setCategoryDataList(response);
        });
      }
    
      async function getThemeListData() {
        getThemeList().then(function (result) {
          const response = result?.data;
          console.log(response, "resresres")
          setThemeDataList(response);
        });
      }

    const onPrint = () => {
        setPrint(true);
        window.print()

    }


    const onClose = () => {
        // navigate("/")
    }
    return (
        <>
            <div className="initiative-info-content">
                <div className="initiative-header">
                    <div className='init-logo'>
                        <img src={logo} alt="logo" className='img-fluid' />
                    </div>
                    <div className="header-title">
                        <h2>Government of West Bengal</h2>
                        <p>Panchayats And Rural Development Department</p>
                    </div>
                </div>
                <div className="initiative-body">
                    <div className='initiate-box'>
                        <div className='initiative-date'>
                            <p className='date'>Date: {format(new Date(value.getDate), 'dd-MM-yyyy')}</p>
                        </div>
                        <h5>Achivements/Initiatives Details</h5>
                        <table>
                            <thead>
                                <tr>
                                    <th style={{ width: '20%' }}>Field</th>
                                    <th>Information</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Name of the Initiative</td>
                                    <td>{value.getInitiative} </td>
                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Details of the Initiative</td>
                                    <td>{value.getDetailsOfInitiatives} </td>

                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Spread of the Initiative</td>
                                    <td>{optionsData.find(c => c.value === value.getSpreadOfInitiative)?.label} </td>


                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Scheme</td>
                                    <td>{getSchemeDataList.find(c => c.schemeId === Number(value.getScheme))?.schemeName} </td>

                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Category</td>
                                    <td>{getCategoryDataList.find(c => c.categoryId === Number(value.getCategory))?.categoryName} </td>

                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Theme</td>
                                    <td>{getThemeDataList.find(c => c.themeId === Number(value.getTheme))?.themeName} </td>


                                </tr>
                            </tbody>

                        </table>
                    </div>
                    <div className='initiate-box'>
                        <h5>Contact details of the Project Head</h5>
                        <table>
                            <thead>
                                <tr>
                                    <th style={{ width: '20%', fontWeight: '700' }}>Field</th>
                                    <th>Information</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Name </td>
                                    <td>{value.getName} </td>
                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Designation</td>
                                    <td>{value.getDesignation}</td>
                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Mobile Number</td>
                                    <td>{value.getMobileNumber}</td>
                                </tr>
                                <tr>
                                    <td style={{ width: '20%', fontWeight: '700' }}>Email id</td>
                                    <td>{value.getEmail}</td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
            {/* {print == true ? "" : */}
            <div className='form-btns' style={{ display: !print ? "block" : "none" }}>
                {/* <button
                    type="button"
                    className="no-print"
                    onClick={onClose}
                ><i class="fa-solid fa-arrow-left fa-2xl"></i></button>
                 */}

                <button
                    type="button"
                    className="no-print"
                    onClick={onPrint}
                    style={{width:"50px"}}
                ><i class="fa-solid fa-print fa-xl "></i></button>
            </div>
            {/* } */}
        </>
    )
}

export default Achivementpdf