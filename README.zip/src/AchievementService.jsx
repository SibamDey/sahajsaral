import webApi, { baseURL } from "./WebApi/WebApi";

export const getSchemeList = async () => {
    return await webApi.get(`/scheme`,);
}
export const getCategoryList = async () => {
    return await webApi.get(`/category`,);
}
export const getThemeList = async () => {
    return await webApi.get(`/theme`,);
}

export const postAchievement = async (data, onSuccess, onFailure) => {
    try {
        const res = await webApi.post(
            `/insert`, data);
        if (res.status === 200) {
            const r = res.data;
            return onSuccess(r);
        } else {
            onFailure("Something Wrong! Please Try again later" + res.data);
        }
    } catch (error) {
        console.log("error")
    }
};


export const draftAchievement = async (data, onSuccess, onFailure) => {
    try {
        const res = await webApi.put(
            `/update`, data);
        if (res.status === 200) {
            const r = res.data;
            return onSuccess(r);
        } else {
            onFailure("Something Wrong! Please Try again later" + res.data);
        }
    } catch (error) {
        console.log("error")
    }
};

//FORWARD
export const ForwardGpAchievement = async (id, gpf, blf, dlf, hqf, gpdate, bldate, distdate, hqdate, createdate,
    onSuccess, onFailure) => {
    console.log(id, gpf, blf, dlf, hqf, gpdate, bldate, distdate, hqdate, createdate, "bodyy")
    try {
        const res = await webApi.put(
            `/update/forwad/${id}`, {
            "gpforward": gpf,
            "blockforward": blf,
            "distforward": dlf,
            "hqforward": hqf,
            "gpdate": gpdate,
            "blockdate": bldate,
            "distdate": distdate,
            "hqdate": hqdate,
            "createdate": createdate

        });
        if (res.status === 200) {
            const r = res.data;
            return onSuccess(r);
        } else {
            onFailure("Something Wrong! Please Try again later" + res.data);
        }
    } catch (error) {
        console.log("error")
    }
};


//RATING
export const ratingBlockAchievement = async (id, gpf, blf, dlf, hqf, gpdate, bldate, distdate, hqdate, createdate,
    blockrating, distrating, blockraterindex, distraterindex, blockratingdate, distratingdate,
    blockremark, distremark, onSuccess, onFailure) => {
    console.log(id, gpf, blf, dlf, hqf, gpdate, bldate, distdate, hqdate, createdate,
        blockrating, distrating, blockraterindex, distraterindex, blockratingdate, distratingdate,
        blockremark, distremark, "bodyy")
    try {
        const res = await webApi.put(
            `/update/forwad/${id}`, {
            "gpforward": gpf,
            "blockforward": blf,
            "distforward": dlf,
            "hqforward": hqf,
            "gpdate": gpdate,
            "blockdate": bldate,
            "distdate": distdate,
            "hqdate": hqdate,
            "createdate": createdate,
            "blockrating": blockrating,
            "distrating": distrating,
            "blockraterindex": blockraterindex,
            "distraterindex": distraterindex,
            "blockratingdate": blockratingdate,
            "distratingdate": distratingdate,
            "blockremark": blockremark,
            "distremark": distremark

        });
        if (res.status === 200) {
            const r = res.data;
            return onSuccess(r);
        } else {
            onFailure("Something Wrong! Please Try again later" + res.data);
        }
    } catch (error) {
        console.log("error")
    }
};


export const getAchievementList = async (category, lgd) => {
    console.log(category, lgd, "datadataataa")
    return await webApi.get(`/list/${category}/${lgd}`, {

    });
}



export const getUserDetails = async (data) => {
    console.log(data, "datadataataa")
    return await webApi.get(`/getMe/${data}`, {

    });
}


export const getAchievementById = async (data) => {
    console.log(data, "datadataataa")
    return await webApi.get(`/details/${data}`, {

    });
}