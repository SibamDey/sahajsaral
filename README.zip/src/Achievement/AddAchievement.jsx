import React, { useState, useEffect, useContext, useRef } from 'react';
import '../../src/assets/css/style.css';
import footer from "../../src/assets/img/mainfooterbg.png"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { getSchemeList, getCategoryList, getThemeList, postAchievement } from "../AchievementService"
import defImg from "../assets/img/download.png"
import { Location } from './LocationContext';
import { useNavigate } from 'react-router-dom';
import { Link, useSearchParams } from 'react-router-dom';
// import DEFAULT from "../../public/DEFAULT.webp"
import Modal from 'react-modal';
import stateStore from "../Achievement/Zustand";
import Navbar from "./Navbar";

const AddAchievement = () => {
  const { value, setValue, setValueImage } = stateStore();
  const imageRef = useRef(null)

  const location = useContext(Location)
  console.log(location, "location")
  const navigate = useNavigate();
  const [params] = useSearchParams();
  console.log(params.get('id'), "PARAMS")
  const handleCloseDelete = () => setShowDelete(false);
  const [showDelete, setShowDelete] = useState(false);
  const [getInitiative, setInitiative] = useState("");
  const [getDetailsOfInitiatives, setDetailsOfInitiatives] = useState("");
  const [getSpreadOfInitiative, setSpreadOfInitiatives] = useState("");
  const [getScheme, setScheme] = useState("");
  const [getCategory, setCategory] = useState("");
  const [getTheme, setTheme] = useState("");
  const [getUniqueOfInitiatives, setUniqueOfInitiatives] = useState("");
  const [getExecutionOfInitiatives, setExecutionOfInitiatives] = useState("");
  const [getImpactOfInitiatives, setImpactOfInitiatives] = useState("");
  const [getMojorChallenges, setMojorChallenges] = useState("");
  const [getSPRS, setSPRS] = useState("");
  const [getStakeholder, setStakeholder] = useState("");
  const [getWebsiteLink, setWebsiteLink] = useState("");
  const [getVideoLink, setVideoLink] = useState("");
  const [getAwardRecognotion, setAwardRecognotion] = useState("");
  const [getName, setName] = useState("");
  const [getDesignation, setDesignation] = useState("");
  const [getMobileNumber, setMobileNumber] = useState('');
  const [getEmail, setEmail] = useState("");
  const [getEmailInput, setEmailInput] = useState("");
  const [getSchemeDataList, setSchemeDataList] = useState([]);
  const [getCategoryDataList, setCategoryDataList] = useState([]);
  const [getThemeDataList, setThemeDataList] = useState([]);
  const [image, setImage] = useState({ preview: "", raw: "" });
  const [getImage, setGetImage] = useState(null);
  const [getImageresult, setGetImageresult] = useState("")

  const [image2, setImage2] = useState({ preview: "", raw: "" });
  const [getImage2, setGetImage2] = useState(null);
  const [getImageresult2, setGetImageresult2] = useState("")
  const [userData, setUserData] = useState(null);
  const [isOpen, setIsOpen] = useState(false);

  console.log(getImage, image, "getImage")
  console.log(value, "stateVal")
  useEffect(() => {
    const jsonString = localStorage.getItem("Achievement_User");
    const data = JSON.parse(jsonString);
    setUserData(data);
    console.log(data?.DIST_LGD, "achievementdata")
    // getAllDepartmentList(data?.departmentNo).then(function (result) {
    //   const response = result?.data?.result;
    //   setAllDepartmentList(response);
    // });
  }, []);


  const onPrint = () => {
    window.print()
  }

  const optionsData = [
    { label: 'State wide', value: 'S' },
    { label: 'District Level', value: 'D' },
    { label: 'Block', value: 'B' },
    { label: 'GP Level', value: 'GP' },
    // Add more options as needed
  ];

  const categoryData = [
    { label: 'Environmental', value: '1' },
    { label: 'Social', value: '2' },
    { label: 'Governance', value: '3' },
 
    // Add more options as needed
  ];
  console.log(params.get('id'), "idididididid")

  const onNameOfInitiative = (e) => {
    setInitiative(e.target.value)
  }

  const onSelectInitiative = (e) => {
    setSpreadOfInitiatives(e.target.value)
  }

  const onScheme = (e) => {
    setScheme(e.target.value)
  }

  const onCategory = (e) => {
    setCategory(e.target.value)
  }

  const onTheme = (e) => {
    setTheme(e.target.value)
  }

  const onDeatilsOfInitiatives = (e) => {
    setDetailsOfInitiatives(e.target.value)
  }

  const onUniqueFeaturesOfInitiatives = (e) => {
    setUniqueOfInitiatives(e.target.value)
  }

  const onExecutionOfInitiatives = (e) => {
    setExecutionOfInitiatives(e.target.value)
  }

  const onImpactOfInitiatives = (e) => {
    setImpactOfInitiatives(e.target.value)
  }

  const onMojorChallenges = (e) => {
    setMojorChallenges(e.target.value)
  }

  const onSPRS = (e) => {
    setSPRS(e.target.value)
  }

  const onStakeholder = (e) => {
    setStakeholder(e.target.value)
  }

  const onWebsiteLink = (e) => {
    setWebsiteLink(e.target.value)
  }

  const onVideoLink = (e) => {
    setVideoLink(e.target.value)
  }

  const onAwardRecognotion = (e) => {
    setAwardRecognotion(e.target.value)
  }

  const onName = (e) => {
    setName(e.target.value)
  }

  const onDesignation = (e) => {
    setDesignation(e.target.value)
  }

  const onMobile = (e) => {
    setMobileNumber(e.target.value)
  }

  const onEmail = (e) => {
    setEmailInput(e.target.value)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    setEmail(emailRegex.test(e.target.value));
  }
  const onPreview = () => {
    if (value.getInitiative === "") {
      toast.error("Please enter name of the Initiative")
    } else if (value.getInitiative.length > 50) {
      toast.error("Name of the Initiative max size 50 words")
    } else if (value.getSpreadOfInitiative === "") {
      toast.error("Please select spread of the Initiative")
    } else if (value.getScheme === "") {
      toast.error("Please select scheme")
    } else if (value.getCategory === "") {
      toast.error("Please select category")
    } else if (value.getTheme === "") {
      toast.error("Please select theme")
    } else if (value.getDetailsOfInitiatives === "") {
      toast.error("Please enter details of Initiative")
    } else if (value.getDetailsOfInitiatives.length > 350) {
      toast.error("Details of Initiative max size 350 words")
    } else if (value.getUniqueOfInitiatives === "") {
      toast.error("Please enter unique features of the Initiative")
    } else if (value.getUniqueOfInitiatives.length > 250) {
      toast.error("unique features of the Initiative max size 250 words")
    } else if (value.getExecutionOfInitiatives === "") {
      toast.error("Please enter Steps involved in the execution of the initiative")
    } else if (value.getExecutionOfInitiatives.length > 200) {
      toast.error("Steps involved in the execution of the initiative max size 200 words")
    } else if (value.getImpactOfInitiatives === "") {
      toast.error("Please enter Impact of the initiative")
    } else if (value.getImpactOfInitiatives.length > 250) {
      toast.error("Impact of the initiative max size 250 words")
    } else if (value.getMojorChallenges === "") {
      toast.error("Please enter Major challenges faced")
    } else if (value.getMojorChallenges.length > 150) {
      toast.error("Major challenges faced max size 150 words")
    } else if (value.getSPRS === "") {
      toast.error("Please enter initiative is scalable, portable, replicable and sustainable")
    } else if (value.getSPRS.length > 350) {
      toast.error("initiative is scalable, portable, replicable and sustainable max size 350 words")
    } else if (value.getStakeholder === "") {
      toast.error("Please enter the stakeholder details")
    } else if (value.getStakeholder.length > 150) {
      toast.error("Stakeholder details max size 150 words")
    } else if (!getImage) {
      toast.error("Please insert first image")
    } else if (!getImage2) {
      toast.error("Please insert second image")
    } else if (value.getName === "") {
      toast.error("Please enter project head name")
    } else if (value.getDesignation === "") {
      toast.error("Please enter project head designation")
    } else if (value.getMobileNumber.length != 10) {
      toast.error("Please enter 10 digit mobile number")
    } else if (value.getEmail === "") {
      toast.error("Please enter project head email id")
    } else if (!value.getEmail) {
      toast.error("Please enter valid email id")
    } else {
      navigate('/achivementpdf')

    }
  }


  const onDraft = () => {

    if (value.getInitiative === "") {
      toast.error("Please enter name of the Initiative")
    } else if (value.getInitiative.length > 50) {
      toast.error("Name of the Initiative max size 50 words")
    } else if (value.getSpreadOfInitiative === "") {
      toast.error("Please select spread of the Initiative")
    } else if (value.getScheme === "") {
      toast.error("Please select scheme")
    } else if (value.getCategory === "") {
      toast.error("Please select category")
    } else if (value.getTheme === "") {
      toast.error("Please select theme")
    } else if (value.getDetailsOfInitiatives === "") {
      toast.error("Please enter details of Initiative")
    } else if (value.getDetailsOfInitiatives.length > 350) {
      toast.error("Details of Initiative max size 350 words")
    } else if (value.getUniqueOfInitiatives === "") {
      toast.error("Please enter unique features of the Initiative")
    } else if (value.getUniqueOfInitiatives.length > 250) {
      toast.error("unique features of the Initiative max size 250 words")
    } else if (value.getExecutionOfInitiatives === "") {
      toast.error("Please enter Steps involved in the execution of the initiative")
    } else if (value.getExecutionOfInitiatives.length > 200) {
      toast.error("Steps involved in the execution of the initiative max size 200 words")
    } else if (value.getImpactOfInitiatives === "") {
      toast.error("Please enter Impact of the initiative")
    } else if (value.getImpactOfInitiatives.length > 250) {
      toast.error("Impact of the initiative max size 250 words")
    } else if (value.getMojorChallenges === "") {
      toast.error("Please enter Major challenges faced")
    } else if (value.getMojorChallenges.length > 150) {
      toast.error("Major challenges faced max size 150 words")
    } else if (value.getSPRS === "") {
      toast.error("Please enter initiative is scalable, portable, replicable and sustainable")
    } else if (value.getSPRS.length > 350) {
      toast.error("initiative is scalable, portable, replicable and sustainable max size 350 words")
    } else if (value.getStakeholder === "") {
      toast.error("Please enter the stakeholder details")
    } else if (value.getStakeholder.length > 150) {
      toast.error("Stakeholder details max size 150 words")
    } else if (!getImage) {
      toast.error("Please insert first image")
    } else if (!getImage2) {
      toast.error("Please insert second image")
    } else if (value.getName === "") {
      toast.error("Please enter project head name")
    } else if (value.getDesignation === "") {
      toast.error("Please enter project head designation")
    } else if (value.getMobileNumber.length != 10) {
      toast.error("Please enter 10 digit mobile number")
    } else if (value.getEmail === "") {
      toast.error("Please enter project head email id")
    } else if (!value.getEmail) {
      toast.error("Please enter valid email id")
    } else {
      let formData = new FormData();
      formData.append('initiativeName', value.getInitiative);
      formData.append('initiativeSpread', value.getSpreadOfInitiative);
      formData.append('schemeId', value.getScheme);
      formData.append('categoryId', value.getCategory);
      formData.append('themeId', value.getTheme);
      formData.append('details', value.getDetailsOfInitiatives);
      formData.append('uniqueDetails', value.getUniqueOfInitiatives);
      formData.append('executionSteps', value.getExecutionOfInitiatives);
      formData.append('impact', value.getImpactOfInitiatives);
      formData.append('challenges', value.getMojorChallenges);
      formData.append('scalability', value.getSPRS);
      formData.append('stakeholderDetails', value.getStakeholder);
      formData.append('website', value.getWebsiteLink);
      formData.append('video', value.getVideoLink);
      formData.append('image', getImage);
      formData.append('image2', getImage2);
      formData.append('awards', value.getAwardRecognotion);
      formData.append('name', value.getName);
      formData.append('designation', value.getDesignation);
      formData.append('mobile', value.getMobileNumber);
      formData.append('email', value.getEmail);
      formData.append('isDraft', 1);
      formData.append('userIndex', userData?.USER_INDEX);

      formData.append('gpforward', userData?.USER_LEVEL === "GP" ? 1 : 0);
      formData.append('blockforward', userData?.USER_LEVEL === "BLOCK" ? 1 : 0);
      formData.append('distforward', userData?.USER_LEVEL === "DIST" ? 1 : 0);
      formData.append('gplgd', userData?.GP_LGD);
      formData.append('blocklgd', userData?.BLOCK_LGD);
      formData.append('distlgd', userData?.DIST_LGD);
      formData.append('category', userData?.USER_LEVEL);

      postAchievement(
        formData,
        (res) => {
          console.log(res, "status101")
          if (res.success === true) {

            navigate(`/${location.search}`)
            toast.success(res.message)

          } else {
            console.log("nononononono")
            toast.error(res.message)

          }
        }
      )
    }
    // navigate('/achivementpdf')

  }
  console.log(getScheme, getCategory, getTheme, "chekh")


  const onSubmit = () => {
    if (value.getInitiative === "") {
      toast.error("Please enter name of the Initiative")
    } else if (value.getInitiative.length > 50) {
      toast.error("Name of the Initiative max size 50 words")
    } else if (value.getSpreadOfInitiative === "") {
      toast.error("Please select spread of the Initiative")
    } else if (value.getScheme === "") {
      toast.error("Please select scheme")
    } else if (value.getCategory === "") {
      toast.error("Please select category")
    } else if (value.getTheme === "") {
      toast.error("Please select theme")
    } else if (value.getDetailsOfInitiatives === "") {
      toast.error("Please enter details of Initiative")
    } else if (value.getDetailsOfInitiatives.length > 350) {
      toast.error("Details of Initiative max size 350 words")
    } else if (value.getUniqueOfInitiatives === "") {
      toast.error("Please enter unique features of the Initiative")
    } else if (value.getUniqueOfInitiatives.length > 250) {
      toast.error("unique features of the Initiative max size 250 words")
    } else if (value.getExecutionOfInitiatives === "") {
      toast.error("Please enter Steps involved in the execution of the initiative")
    } else if (value.getExecutionOfInitiatives.length > 200) {
      toast.error("Steps involved in the execution of the initiative max size 200 words")
    } else if (value.getImpactOfInitiatives === "") {
      toast.error("Please enter Impact of the initiative")
    } else if (value.getImpactOfInitiatives.length > 250) {
      toast.error("Impact of the initiative max size 250 words")
    } else if (value.getMojorChallenges === "") {
      toast.error("Please enter Major challenges faced")
    } else if (value.getMojorChallenges.length > 150) {
      toast.error("Major challenges faced max size 150 words")
    } else if (value.getSPRS === "") {
      toast.error("Please enter initiative is scalable, portable, replicable and sustainable")
    } else if (value.getSPRS.length > 350) {
      toast.error("initiative is scalable, portable, replicable and sustainable max size 350 words")
    } else if (value.getStakeholder === "") {
      toast.error("Please enter the stakeholder details")
    } else if (value.getStakeholder.length > 150) {
      toast.error("Stakeholder details max size 150 words")
    } else if (!getImage) {
      toast.error("Please insert first image")
    } else if (!getImage2) {
      toast.error("Please insert second image")
    } else if (value.getName === "") {
      toast.error("Please enter project head name")
    } else if (value.getDesignation === "") {
      toast.error("Please enter project head designation")
    } else if (value.getMobileNumber.length != 10) {
      toast.error("Please enter 10 digit mobile number")
    } else if (value.getEmail === "") {
      toast.error("Please enter project head email id")
    } else if (!value.getEmail) {
      toast.error("Please enter valid email id")
    } else {
      let formData = new FormData();
      formData.append('initiativeName', value.getInitiative);
      formData.append('initiativeSpread', value.getSpreadOfInitiative);
      formData.append('schemeId', value.getScheme);
      formData.append('categoryId', value.getCategory);
      formData.append('themeId', value.getTheme);
      formData.append('details', value.getDetailsOfInitiatives);
      formData.append('uniqueDetails', value.getUniqueOfInitiatives);
      formData.append('executionSteps', value.getExecutionOfInitiatives);
      formData.append('impact', value.getImpactOfInitiatives);
      formData.append('challenges', value.getMojorChallenges);
      formData.append('scalability', value.getSPRS);
      formData.append('stakeholderDetails', value.getStakeholder);
      formData.append('website', value.getWebsiteLink);
      formData.append('video', value.getVideoLink);
      formData.append('image', getImage);
      formData.append('image2', getImage2);
      formData.append('awards', value.getAwardRecognotion);
      formData.append('name', value.getName);
      formData.append('designation', value.getDesignation);
      formData.append('mobile', value.getMobileNumber);
      formData.append('email', value.getEmail);
      formData.append('isDraft', 0);
      formData.append('userIndex', userData?.USER_INDEX);

      formData.append('gpforward', userData?.USER_LEVEL === "GP" ? 1 : 0);
      formData.append('blockforward', userData?.USER_LEVEL === "BLOCK" ? 1 : 0);
      formData.append('distforward', userData?.USER_LEVEL === "DIST" ? 1 : 0);
      formData.append('gplgd', userData?.GP_LGD);
      formData.append('blocklgd', userData?.BLOCK_LGD);
      formData.append('distlgd', userData?.DIST_LGD);
      formData.append('category', userData?.USER_LEVEL);

      postAchievement(
        formData,
        (res) => {
          console.log(res, "status101")
          if (res.success === true) {

            navigate(`/${location.search}`)
            toast.success(res.message)

          } else {
            console.log("nononononono")
            toast.error(res.message)

          }
        }
      )
    }
  }

  //scheme data fetching
  //category data fetching
  //theme data fetching

  useEffect(() => {
    getSchemeListData();
    getCategoryListData();
    getThemeListData();
  }, []);

  async function getSchemeListData() {
    getSchemeList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setSchemeDataList(response);
    });
  }

  async function getCategoryListData() {
    getCategoryList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setCategoryDataList(response);
    });
  }

  async function getThemeListData() {
    getThemeList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setThemeDataList(response);
    });
  }


  //image proccessing
  const onFile = (event) => {
    console.log(event.target.files[0], "filee")
    if (event["target"].files.length > 0) {
      const file = event["target"].files[0];
      // setUserData({...userData, profileImage : file});
      setValueImage("image", {
        preview: URL.createObjectURL(event.target.files[0]),
        raw: event.target.files[0]
      });
      console.log(image, "asdsdsd")
      setGetImage(file)
      setGetImageresult(file.name)
      //     const reader = new FileReader();
      //     reader.readAsDataURL(file);
      //     reader.onload = (event) => {
      //         setGetImageresult(reader.result);
      //   };
    }

  }
  //image proccessing for second input
  const onFile2 = (event) => {
    console.log(event.target.files[0], "filee")
    if (event["target"].files.length > 0) {
      const file = event["target"].files[0];
      // setUserData({...userData, profileImage : file});
      setValueImage("image2", {
        preview: URL.createObjectURL(event.target.files[0]),
        raw: event.target.files[0]
      });
      console.log(image, "101823")
      setGetImage2(file)
      setGetImageresult2(file.name)
      //     const reader = new FileReader();
      //     reader.readAsDataURL(file);
      //     reader.onload = (event) => {
      //         setGetImageresult(reader.result);
      //   };
    }

  }

  return (
    <div>
      {/* <Modal isOpen={isOpen} onRequestClose={() => setIsOpen(false)} >

          <div className="initiative-info-content">
            <div className="initiative-header">
              <div className='init-logo'>
                <img src={logo} alt="logo" className='img-fluid' />
              </div>
              <div className="header-title">
                <h2>Government of West Bengal</h2>
                <p>Panchayats And Rural Development Department</p>
              </div>
            </div>
            <div className="initiative-body">
              <div className='initiate-box'>
                <div className='initiative-date'>
                  <p className='date'>Date: 29-Apr-2024</p>
                </div>
                <h5>Achivements/Initiatives Details</h5>
                <table>
                  <thead>
                    <tr>
                      <th style={{width: '20%'}}>Field</th>
                      <th>Information</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={{width: '20%'}}>Name of the Initiative</td>
                      <td>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Labore non ad dolorem soluta. Repudiandae dolorum labore beatae, praesentium sapiente voluptates.</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Details of the Initiative</td>
                      <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo minima voluptatem minus corrupti maxime eligendi nostrum deserunt modi atque inventore?</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Spread of the Initiative</td>
                      <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo minima voluptatem minus corrupti maxime eligendi nostrum deserunt modi atque inventore?</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Scheme</td>
                      <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo minima voluptatem minus corrupti maxime eligendi nostrum deserunt modi atque inventore?</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Category</td>
                      <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo minima voluptatem minus corrupti maxime eligendi nostrum deserunt modi atque inventore?</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Theme</td>
                      <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo minima voluptatem minus corrupti maxime eligendi nostrum deserunt modi atque inventore?</td>
                    </tr>
                  </tbody>

                </table>
              </div>
              <div className='initiate-box'>
                <h5>Contact details of the Project Head</h5>
                <table>
                  <thead>
                    <tr>
                      <th style={{width: '20%'}}>Field</th>
                      <th>Information</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={{width: '20%'}}>Name </td>
                      <td>Rakesh Kumar Barman </td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Designation</td>
                      <td>Software Devloper Engineer</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Mobile Number</td>
                      <td>9175853480</td>
                    </tr>
                    <tr>
                      <td style={{width: '20%'}}>Email id</td>
                      <td>example@gmail.com</td>
                    </tr>
                  </tbody>

                </table>
              </div>
            </div>
          </div>
          <button
          type="button"
          className="btn "
          >Close</button>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          
          <button
          type="button"
          className="btn"
          onClick={onPrint}
          >Print</button>
         
   
        
      </Modal> */}
      <ToastContainer />
      {/* <div className="navbar ">
        <div className="wrapper">
          <div
            className="title-bar"
            data-responsive-toggle="example-animated-menu"
            data-hide-for="medium"
          >
            <button className="menu-icon" type="button" data-toggle="" />
            <div className="title-bar-title">Menu</div>

          </div>
          <div
            className="title-bar"
            id="example-animated-menu"
            data-animate="hinge-in-from-top fade-out"
          >
            <div className="title-bar-left">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="index.html">
                    <i className="fa fa-home" aria-hidden="true" />
                    Home
                  </a>
                </li>
                <li>
                  <a href="form.html">About Us</a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-line-chart" aria-hidden="true" />
                    Analytics
                  </a>
                </li>
                <li>
                  <a href="#">Reports</a>
                </li>
                <li>
                  <a href="#">Initiatives</a>
                </li>
              </ul>
            </div>
            <div className="title-bar-right">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="login.html" className="btn float-right">
                    Login (Registered User)
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div> */}
      <Navbar />

      <div className="grid-container mn_ht">
        <div className="grid-x grid-margin-x">
          <form data-abide="" noValidate="">
            <div className="grid-x grid-margin-x">
              <div className="cell">
                <div
                  data-abide-error=""
                  className="alert callout"
                  style={{ display: "none" }}
                >
                  <p>
                    <i className="fi-alert" /> There are some errors in your form.
                  </p>
                </div>
              </div>
            </div>
            <div>
              <h3 style={{ marginLeft: 450, marginTop: 20 ,color:"orange"}}>Achievement/Initiatives Form</h3>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Name of the Initiative&nbsp;(Max 50 Words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getInitiative}
                    // onChange={onNameOfInitiative}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getInitiative'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell medium-3">
                <label>
                  <b>
                    Spread of the Initiative<span style={{ color: "red" }}> *</span>
                  </b>
                </label>
                <select name='getSpreadOfInitiative' id="select" required="" onChange={(e) => setValue(e.target)}>
                  <option selected disabled>
                    Select
                  </option>
                  {optionsData.map(option => (
                    <option value={option.value}>{option.label}</option>
                  ))}
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Scheme<span style={{ color: "red" }}> *</span></b>
                </label>
                <select name='getScheme' id="select" required="" onChange={(e) => setValue(e.target)}>
                  <option selected disabled>
                    Select Scheme
                  </option>
                  {getSchemeDataList?.map((d) => (
                    <option value={d?.schemeId}>{d?.schemeName}</option>

                  ))}
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Category<span style={{ color: "red" }}> *</span></b>
                </label>
                <select name='getCategory' id="select" required="" onChange={(e) => setValue(e.target)}>
                  <option selected disabled>
                    Select Category
                  </option>
                  {categoryData.map(option => (
                    <option value={option.value}>{option.label}</option>
                  ))}
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Theme<span style={{ color: "red" }}> *</span></b>
                </label>
                <select name='getTheme' id="select" required="" onChange={(e) => setValue(e.target)}>
                  <option selected disabled>
                    Select Theme
                  </option>
                  {getThemeDataList?.map((d) => (
                    <option value={d?.themeId}>{d?.themeName}</option>

                  ))}
                </select>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Details of Initiative&nbsp;(Max 350 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getDetailsOfInitiatives}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getDetailsOfInitiatives'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Unique features of the initiative&nbsp;(Max 250 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getUniqueOfInitiatives}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getUniqueOfInitiatives'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Steps involved in the execution of the initiative&nbsp;(Max 200
                    words)<span style={{ color: "red" }}>*</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getExecutionOfInitiatives}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getExecutionOfInitiatives'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Impact of the initiative?&nbsp;(Max 250 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getImpactOfInitiatives}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getImpactOfInitiatives'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Major challenges faced and overcome the challenges during the
                    project execution.&nbsp;(Max 150 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getMojorChallenges}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getMojorChallenges'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Is the initiative is scalable, portable, replicable and
                    sustainable?&nbsp;(Max 350 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getSPRS}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getSPRS'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Please enter the stakeholder details.&nbsp;(Max 150 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={value.getStakeholder}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getStakeholder'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-6">
                <label>
                  <b>Website Link</b>
                  <input
                    type="text"
                    placeholder="Website Link"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={(e) => setValue(e.target)}
                    name='getWebsiteLink'
                    value={value.getWebsiteLink}
                    style={{ resize: 'none'}}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>Video Link</b>
                  <input
                    type="text"
                    placeholder="Video Link"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={(e) => setValue(e.target)}
                    name='getVideoLink'
                    value={value.getVideoLink}
                    

                  />
                </label>
              </div>
            </div>
            <br></br>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label className="form-label" htmlFor="customFile">
                  <b>
                    Upload photos of the initiative.&nbsp;(Supported file formats
                    .jpeg .png, Max File Size : 2MB )
                    <span style={{ color: "red" }}> *</span>
                  </b>
                </label>
              </div>

              <div className="cell small-4">
                <input type="file" ref={imageRef} id="customFile" accept="image/png, image/jpeg" onChange={(e) => {
                  onFile(e);
                  
                  console.log(imageRef, "imagedata")
                }} />

              </div>

              <div className="cell small-2">
                <img src={value.image.preview ? value.image.preview : defImg} width="60" height="60" />
              </div>
              <div className="cell small-4">
                <input type="file" id="customFile" accept="image/png, image/jpeg" onChange={onFile2} />

              </div>

              <div className="cell small-2">
                <img src={value.image2.preview ? value.image2.preview : defImg} width="60" height="80" />
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Awards Recognition / Any other details&nbsp;(Name of Award and
                    Award Conferring Authority)&nbsp;(Max 150 words)
                  </b>
                  <textarea
                    type="textarea"
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    // defaultValue={""}
                    value={value.getAwardRecognotion}
                    onChange={(e) => setValue(e.target)}
                    style={{ resize: 'none'}}
                    name='getAwardRecognotion'

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <h5>
                  Contact details of the Project Head
                  <span style={{ color: "red" }}> *</span>
                </h5>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Name<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your name"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    // onChange={onName}
                    onChange={(e) => setValue(e.target)}
                    name='getName'
                    value={value.getName}
                    style={{ resize: 'none'}}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Designation<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your designation"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    // onChange={onDesignation}
                    onChange={(e) => setValue(e.target)}
                    name='getDesignation'
                    value={value.getDesignation}
                    style={{ resize: 'none'}}


                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Mobile Number<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="number"
                    placeholder="Enter your mobile number"
                    aria-describedby="exampleHelpTextNumber"
                    // onChange={onMobile}
                    onChange={(e) => setValue(e.target)}
                    name='getMobileNumber'
                    style={{ resize: 'none'}}

                    value={value.getMobileNumber}
                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Email id<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your email id"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    // onChange={onEmail}
                    onChange={(e) => setValue(e.target)}
                    name='getEmail'
                    style={{ resize: 'none'}}

                    value={value.getEmail}
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">

              <div className="cell small-1">
                <button
                  className='btn'
                  style={{ marginLeft: "915px", marginTop: "10px" }}
                  onClick={onPreview}

                >
                  Preview
                </button>
              </div>

              <div className="cell small-1">
                <button
                  className='btn'
                  style={{ marginLeft: "920px", marginTop: "10px" }}
                  onClick={onDraft}

                >
                  Draft
                </button>
              </div>
              <div className="cell small-1">
                <button
                  className='btn'
                  // className="btn float-left"
                  style={{ marginLeft: "910px", marginTop: "10px" }}
                  onClick={onSubmit}
                >
                  Submit
                </button>
              </div>
            </div>

          </form>
        </div>
      </div>


      <nav className="footer">
        <img src={footer} />
        <p className="text-center lastp" style={{ fontSize: "26px !important" }}><strong>©</strong>
          2024 Designed and Developed By <b>IT And Statistical Cell,</b> Panchayat & Rural
          Development Department <b>Govt. of West Bengal</b>
        </p>
        <p className="text-center lastp" style={{ fontSize: "26px !important" }}>Site best viewed with 1920x1080 resolution in
          Google Chrome 31.0.1650.63, Firefox 55.0.2, Safari 5.1.7 & IE 11.0 and above</p>
      </nav>
      {/* <Modal show={showDelete} onHide={handleCloseDelete}>
        <Modal.Header closeButton>
          <Modal.Title>Are you sure to delete ?</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;

        </Modal.Body>
      </Modal> */}
    </div>
  )
}

export default AddAchievement;