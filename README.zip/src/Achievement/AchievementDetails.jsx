import React, { useState, useEffect } from 'react';
import '../../src/assets/css/style.css';
import footer from "../../src/assets/img/mainfooterbg.png"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate, useLocation } from 'react-router-dom';
import { getAchievementById } from '../AchievementService'
import defImg from "../assets/img/simple-user-default-icon-free-png.webp"
import { getSchemeList, getCategoryList, getThemeList } from "../AchievementService"
import Navbar from "./Navbar";
const AchievementDetails = () => {
  const location = useLocation();
  const achievementId = new URLSearchParams(location.search);
  const navigate = useNavigate();

  const [getSchemeDataList, setSchemeDataList] = useState([]);
  const [getCategoryDataList, setCategoryDataList] = useState([]);
  const [getThemeDataList, setThemeDataList] = useState([]);

  const [getAchievementId, setAchievementId] = useState({})
  console.log(getAchievementId, "getAchievementId")
  const onBack = () => {
    navigate("/")
  }

  console.log(getSchemeDataList, "getSchemeDataList")
  console.log(getCategoryDataList, "getCategoryDataList")
  console.log(getThemeDataList, "getThemeDataList")

  //api calling for category ,theme,scheme listing
  useEffect(() => {
    getSchemeListData();
    getCategoryListData();
    getThemeListData();
  }, []);

  async function getSchemeListData() {
    getSchemeList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setSchemeDataList(response);
    });
  }

  async function getCategoryListData() {
    getCategoryList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setCategoryDataList(response);
    });
  }

  async function getThemeListData() {
    getThemeList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setThemeDataList(response);
    });
  }


  useEffect(() => {
    getAllAchievementList()
  }, [])

  async function getAllAchievementList() {
    getAchievementById(achievementId.get(`id`)).then(function (result) {
      const response = result?.data;
      console.log(response, "response")
      setAchievementId(response);
    });
  }

  const optionsData = [
    { label: 'State wide', value: 'S' },
    { label: 'District Level', value: 'D' },
    { label: 'Block', value: 'B' },
    { label: 'GP Level', value: 'GP' },
  ];
  return (
    <div>
      <ToastContainer />
      <Navbar />
      {/* <div className="navbar ">
        <div className="wrapper">
          <div
            className="title-bar"
            data-responsive-toggle="example-animated-menu"
            data-hide-for="medium"
          >
            <button className="menu-icon" type="button" data-toggle="" />
            <div className="title-bar-title">Menu</div>

          </div>
          <div
            className="title-bar"
            id="example-animated-menu"
            data-animate="hinge-in-from-top fade-out"
          >
            <div className="title-bar-left">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="index.html">
                    <i className="fa fa-home" aria-hidden="true" />
                    Home
                  </a>
                </li>
                <li>
                  <a href="form.html">About Us</a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-line-chart" aria-hidden="true" />
                    Analytics
                  </a>
                </li>
                <li>
                  <a href="#">Reports</a>
                </li>
                <li>
                  <a href="#">Initiatives</a>
                </li>
              </ul>
            </div>
            <div className="title-bar-right">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="login.html" className="btn float-right">
                    Login (Registered User)
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div> */}


      <div className="grid-container mn_ht">
        <div className="grid-x grid-margin-x">
          <form data-abide="" noValidate="">
            <div className="grid-x grid-margin-x">
              <div className="cell">
                <div
                  data-abide-error=""
                  className="alert callout"
                  style={{ display: "none" }}
                >
                  <p>
                    <i className="fi-alert" /> There are some errors in your form.
                  </p>
                </div>
              </div>
            </div>
            <div>
              <h3 style={{ marginLeft: 400, marginTop: 20 }}>Achievement/Initiatives Details</h3>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Name of the Initiative&nbsp;(Max 50 Words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    style={{ resize: 'none' }}
                    readOnly
                    value={getAchievementId?.INITIATIVE_NAME}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell medium-3">
                <label>
                  <b>
                    Spread of the Initiative<span style={{ color: "red" }}> *</span>
                  </b>
                </label>
                <select id="select" required="" disabled>
                  <option>{optionsData.find(c => c.value === getAchievementId?.INITIATIVE_SPREAD)?.label}</option>
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Scheme<span style={{ color: "red" }}> *</span></b>
                </label>
                <select id="select" required="" disabled>

                  <option>{getSchemeDataList.find(c => c.schemeId === getAchievementId?.SCHEME_ID)?.schemeName}</option>
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Category<span style={{ color: "red" }}> *</span></b>
                </label>
                <select id="select" required="" disabled>
                  <option>{getCategoryDataList.find(c => c.categoryId === getAchievementId?.CATEGORY_ID)?.categoryName}</option>

                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Theme<span style={{ color: "red" }}> *</span></b>
                </label>
                <select id="select" required="" disabled>
                  <option>{getThemeDataList.find(c => c.themeId === getAchievementId?.THEME_ID)?.themeName}</option>

                </select>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Details of Initiative&nbsp;(Max 350 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    style={{ resize: 'none' }}
                    readOnly
                    value={getAchievementId?.DETAILS}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Unique features of the initiative&nbsp;(Max 250 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.UNIQUE_DETAILS}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Steps involved in the execution of the initiative&nbsp;(Max 200
                    words)<span style={{ color: "red" }}>*</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.EXECUTION_STEPS}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Impact of the initiative?&nbsp;(Max 250 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.IMPACT}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Major challenges faced and overcome the challenges during the
                    project execution.&nbsp;(Max 150 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.CHALLENGES}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Is the initiative is scalable, portable, replicable and
                    sustainable?&nbsp;(Max 350 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.SCALABILITY}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Please enter the stakeholder details.&nbsp;(Max 150 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.STAKEHOLDER_DETAILS}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-6">
                <label>
                  <b>Website Link</b>
                  <input
                    type="text"
                    placeholder="Website Link"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    readOnly
                    value={getAchievementId?.WEBSITE}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>Video Link</b>
                  <input
                    type="text"
                    placeholder="Video Link"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    readOnly
                    value={getAchievementId?.VIDEO}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label className="form-label" htmlFor="customFile">
                  <b>
                    Upload photos of the initiative.&nbsp;(Supported file formats
                    .jpeg ; Max File Size : 2MB )
                    <span style={{ color: "red" }}> *</span>
                  </b>
                </label>
              </div>
              <div className="cell small-6">
                <img src={`http://wbpms.in:8085/uploads/${getAchievementId?.image}` ? `http://wbpms.in:8085/uploads/${getAchievementId?.image}` : defImg} width="100" height="0" />

              </div>
              <div className="cell small-6">
                <img src={`http://wbpms.in:8085/uploads/${getAchievementId?.image2}` ? `http://wbpms.in:8085/uploads/${getAchievementId?.image2}` : defImg} width="100" height="0" />


              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Awards Recognition / Any other details&nbsp;(Name of Award and
                    Award Conferring Authority)&nbsp;(Max 150 words)
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    value={getAchievementId?.AWARDS}
                    style={{ resize: 'none' }}
                    readOnly
                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <h5>
                  Contact details of the Project Head
                  <span style={{ color: "red" }}> *</span>
                </h5>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Name<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your name"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    readOnly
                    value={getAchievementId?.PROJECT_HEAD_NAME}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Designation<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your designation"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    readOnly
                    value={getAchievementId?.DESIGNATION}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Mobile Number<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="number"
                    placeholder="Enter your mobile number"
                    aria-describedby="exampleHelpTextNumber"
                    readOnly
                    value={getAchievementId?.MOBILE}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Email id<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your email id"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    readOnly
                    value={getAchievementId?.EMAIL}

                  />
                </label>
              </div>
            </div>
            <span>&nbsp;</span>
          </form>
        </div>
      </div>


      <nav className="footer">
        <img src={footer} />
        <p className="text-center lastp" style={{ fontSize: "16px !important" }}><strong>©</strong>
          2024 Designed and Developed By <b>IT And Statistical Cell,</b> Panchayat & Rural
          Development Department <b>Govt. of West Bengal</b>
        </p>
        <p className="text-center lastp" style={{ fontSize: "14px !important" }}>Site best viewed with 1920x1080 resolution in
          Google Chrome 31.0.1650.63, Firefox 55.0.2, Safari 5.1.7 & IE 11.0 and above</p>
      </nav>

    </div>
  )
}

export default AchievementDetails;