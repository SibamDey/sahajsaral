import React from "react"
const Navbar=()=>{
return(
<div class="wrapper">

<div class="grid-x grid-padding-x">
    <div class="large-1 medium-1 small-12 cell">
        <div class="grid-x grid-margin-x align-left">
            <div class="large-12 medium-12 small-12 cell">
                <img src="biswa_bangla.gif" style={{"padding":"10px"}}/>
            </div>
        </div>
    </div>
    <div class="large-10 medium-10 small-12 cell">
        <div class="grid-x grid-margin-x align-center">
            <div class="large-4 medium-4 small-12 cell">
                <a href="#">
                    <img src="logo_pms.png" /></a>
            </div>
        </div>
    </div>
</div>
</div>
)
}
export default Navbar;

