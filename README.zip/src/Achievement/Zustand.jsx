import { create } from 'zustand'
 const currentDate = new Date();

  // Format the date (e.g., as a string)
  const formattedDate = currentDate.toLocaleDateString();
const stateStore = create(
    (set) => ({
        value: {
            "getDate":formattedDate,
            "getInitiative": "",
            "getDetailsOfInitiatives": "",
            "getSpreadOfInitiative": "",
            "getScheme": "",
            "getCategory": "",
            "getTheme": "",
            "getUniqueOfInitiatives": "",
            "getExecutionOfInitiatives": "",
            "getImpactOfInitiatives": "",
            "getMojorChallenges": "",
            "getSPRS": "",
            "getStakeholder": "",
            "getWebsiteLink": "",
            "getVideoLink": "",
            "getAwardRecognotion": "",
            "getName": "",
            "getDesignation": "",
            "getMobileNumber": "",
            "getEmail": "",
            "getEmailInput": "",
            "getSchemeDataList": [],
            "getCategoryDataList": [],
            "getThemeDataList": [],
            "image": {
                "preview": "",
                "raw": ""
            },
            "getImage": null,
            "getImageresult": "",
            "image2": {
                "preview": "",
                "raw": ""
            },
            "getImage2": null,
            "getImageresult2": ""
        },
        setValue: (id) => set((e) => ({
            value:{
                ...e.value,
                [id.name] : id.value
            } 
        })),

        setValueImage: (key,value) => set((e) => ({
            value:{
                ...e.value,
                [key]:value
            } 
        }))


    })


)

export default stateStore