import React, { useState, useEffect } from 'react';
import '../../src/assets/css/style.css';
import footer from "../../src/assets/img/mainfooterbg.png"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { getAchievementList, getUserDetails, ForwardGpAchievement, ratingBlockAchievement } from "../AchievementService"
import { Link, useSearchParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import Modal from 'react-modal';
import Navbar from "./Navbar";

const AchievementList = () => {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  console.log(params.get('evnt_index'), "papapa")
  console.log([...params])
  const handleCloseDelete = () => setShowDelete(false);
  const [showDelete, setShowDelete] = useState(false);
  const [achievementList, setAchievementList] = useState([]);
  const [integerValue, setIntegerValue] = useState(null);
  const [blockList, setBlockList] = useState();
  const [userData, setUserData] = useState(null);
  const [remark, setRemark] = useState("");

  console.log(achievementList, "achievementList")
  //Achievement all data List
  const [isOpen, setIsOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [dataRating, setDataRating] = useState();

  const handleRatingClick = (value) => {
    setRating(value);
    console.log(value, "ratingvalue")
    // setIsOpen(false); // Close the modal after rating is selected
  };



  //modal css

  useEffect(() => {
    convertToInteger();
    // getallAchievementList()

  }, []);

  useEffect(() => {

    const jsonString = localStorage.getItem("Achievement_User");
    const data = JSON.parse(jsonString);
    setUserData(data);
    console.log(data, "data")

    getAchievementList(data?.USER_LEVEL, data?.USER_LEVEL === "GP" ? data?.GP_LGD : data?.USER_LEVEL === "BLOCK" ? data?.BLOCK_LGD : data?.USER_LEVEL === "DIST" ? data?.DIST_LGD : "").then(function (result) {
      const response = result?.data;
      setAchievementList(response);
      setBlockList(response?.role)
    });
  }, []);

  async function getallAchievementList() {
    getAchievementList(userData?.USER_LEVEL, userData?.USER_LEVEL === "GP" ? userData?.GP_LGD : userData?.USER_LEVEL === "BLOCK" ? userData?.BLOCK_LGD : userData?.USER_LEVEL === "DIST" ? userData?.DIST_LGD : "").then(function (result) {
      const response = result?.data;
      setAchievementList(response);
      setBlockList(response?.role)
    });
  }
  const convertToInteger = () => {
    // Decode the Base64 string
    const decodedString = atob(params.get('evnt_index'));
    // Parse the resulting string into an integer
    const integerValue = parseInt(decodedString, 10);
    // Update the state to reflect the converted value
    console.log(integerValue, "integerValue")
    setIntegerValue(integerValue);

    getUserDetails(integerValue).then(function (result) {
      const response = result?.data;
      localStorage.setItem("Achievement_User", JSON.stringify(response));
    });


  };
  console.log(integerValue, "integerValue")

  console.log(params.get('evnt_index'))
  console.log(params)
  // console.log(integerValue)

  const onAddaAchievement = () => {
    navigate(`/add-achievement?evnt=${params.get('evnt')}=&evnt_index=${params.get('evnt_index')}&evnl=${params.get('evnl')}`)

  }

  const onGpForward = (d) => {
    console.log(d, "FORWARD")
    ForwardGpAchievement(
      d?.INITIATIVE_ID, d?.GP_FORWARD, 2, d?.DIST_FORWARD,
      d?.HQ_FORWARD, "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22",
      (res) => {
        console.log(res, "status101")
        if (res.success === true) {
          toast.success("Achievement Forwarded to Block Successfully")
          getallAchievementList()
        } else {
          console.log("nononononono")
          toast.error(res.message)

        }
      }
    )
  }


  const onBlockForward = (d) => {
    console.log(d, "FORWARD")
    ForwardGpAchievement(
      d?.INITIATIVE_ID, d?.GP_FORWARD, d?.BLOCK_FORWARD, 2,
      d?.HQ_FORWARD, "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22",
      (res) => {
        console.log(res, "status101")
        if (res.success === true) {
          toast.success("Achievement Forwarded to District Successfully")
          getallAchievementList()

        } else {
          console.log("nononononono")
          toast.error(res.message)

        }
      }
    )
  }

  const onDistForward = (d) => {
    console.log(d, "FORWARD")
    ForwardGpAchievement(
      d?.INITIATIVE_ID, d?.GP_FORWARD, d?.BLOCK_FORWARD, d?.DIST_FORWARD,
      2, "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22",
      (res) => {
        console.log(res, "status101")
        if (res.success === true) {
          toast.success("Achievement Forwarded to State Successfully")

        } else {
          console.log("nononononono")
          toast.error(res.message)

        }
      }
    )
  }

  const onStar = (d) => {
    setDataRating(d)
    setIsOpen(true)
  }

  const onRatingBlockSubmit = () => {
    if (rating == 0) {
      toast.error("Please Put Your Rating")
    } else if (remark === "") {
      toast.error("Please Enter Remarks")
    } else if (remark.length > 50) {
      toast.error("Details of Remarks max size 50 words")
    }
    else {
      ratingBlockAchievement(
        dataRating?.INITIATIVE_ID, dataRating?.GP_FORWARD, dataRating?.BLOCK_FORWARD, dataRating?.DIST_FORWARD,
        dataRating?.HQ_FORWARD, "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22", rating,
        dataRating?.DIST_RATING, dataRating?.BLOCK_RATER_INDEX, dataRating?.DIST_RATER_INDEX, dataRating?.BLOCK_RATING_DATE, dataRating?.DIST_RATING_DATE,
        remark, dataRating?.DIST_REMARK,
        (res) => {
          console.log(res, "status101")
          if (res.success === true) {
            toast.success("Thank you for your review")
            setIsOpen(false)

          } else {
            console.log("nononononono")
            toast.error(res.message)

          }
        }
      )
    }
  }

  const onRatingDistSubmit = () => {
    if (rating == 0) {
      toast.error("Please Put Your Rating")
    } else if (remark === "") {
      toast.error("Please Enter Remarks")
    } else if (remark.length > 50) {
      toast.error("Details of Remarks max size 50 words")
    }
    else {
      ratingBlockAchievement(
        dataRating?.INITIATIVE_ID, dataRating?.GP_FORWARD, dataRating?.BLOCK_FORWARD, dataRating?.DIST_FORWARD,
        dataRating?.HQ_FORWARD, "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22", "2024-04-22",
        dataRating?.BLOCK_RATING, rating, dataRating?.BLOCK_RATER_INDEX, dataRating?.DIST_RATER_INDEX, dataRating?.BLOCK_RATING_DATE, dataRating?.DIST_RATING_DATE,
        dataRating?.BLOCK_REMARK, remark,
        (res) => {
          console.log(res, "status101")
          if (res.success === true) {
            toast.success("Thank you for your review")
            setIsOpen(false)

          } else {
            console.log("nononononono")
            toast.error(res.message)

          }
        }
      )
    }
  }

  const onRemark = (e) => {
    setRemark(e.target.value)
  }

  return (
    <div>
      <Modal isOpen={isOpen} onRequestClose={() => setIsOpen(false)} className='xx'>
        <h2 className='text-center' style={{ color: "White" }}>Rate the Achievement</h2>
        <hr style={{ borderBottom: "3px solid #cacaca" }}></hr>
        <div className='grid-x grid-padding-x align-center'>
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((value) => (


            <div align="center" className='float-left'
              key={value}
              onClick={() => handleRatingClick(value)}
              style={{ cursor: 'pointer', color: value <= rating ? 'gold' : 'gray', fontSize: "50px" }}
            >
              ★
            </div>


          ))}
        </div>

        <div className="grid-x grid-margin-x">
          <div className="cell small-12">
            <label style={{ color: "White", fontSize: "15px" }}>
              Remark&nbsp;(Max 50 words)
              <span style={{ color: "red" }}> *</span>

              <textarea
                // className="form-control"
                // id="exampleFormControlTextarea1"
                rows={3}
                // defaultValue={getDetailsOfInitiatives}
                onChange={onRemark}
                style={{ resize: 'none' }}

              />
            </label>
          </div>
        </div>
        <div className='grid-x grid-padding-x align-center'>

          <button
            type="button"
            className="btn float-left"
            onClick={() => setIsOpen(false)}>Close</button>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          {userData?.USER_LEVEL === "BLOCK" ?
            <button
              type="button"
              className="btn float-left"
              onClick={onRatingBlockSubmit}>
              Submit
            </button> : userData?.USER_LEVEL === "DIST" ? <button
              type="button"
              className="btn float-left"
              onClick={onRatingDistSubmit}>
              Submit
            </button> : ""}

        </div>

      </Modal>

      <ToastContainer />
      {/* <div className="navbar "> */}
      {/* <div className="wrapper">
          <div
            className="title-bar"
            data-responsive-toggle="example-animated-menu"
            data-hide-for="medium"
          >
            <button className="menu-icon" type="button" data-toggle="" />
            <div className="title-bar-title">Menu</div>

          </div>
          <div
            className="title-bar"
            id="example-animated-menu"
            data-animate="hinge-in-from-top fade-out"
          >
            <div className="title-bar-left">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="index.html">
                    <i className="fa fa-home" aria-hidden="true" />
                    Home
                  </a>
                </li>
                <li>
                  <a href="form.html">About Us</a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-line-chart" aria-hidden="true" />
                    Analytics
                  </a>
                </li>
                <li>
                  <a href="#">Reports</a>
                </li>
                <li>
                  <a href="#">Initiatives</a>
                </li>
              </ul>
            </div>
            <div className="title-bar-right">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="login.html" className="btn float-right">
                    Login (Registered User)
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div> */}
      {/* </div> */}
      <div className='container-fluid'>
        <div className='dbMain businessUnit'>
          <div className='dbRight'>
            <Navbar />

            {/* <Header link="/dashboard" breadcm="Configuration > " title="Business unit" description="There are many variations of passages of Lorem Ipsum available." /> */}
            <div className='commonBase'>
            <div>
              <h3 style={{ marginLeft: "540px", marginTop: "-10px" ,color:"orange"}}>Achievement/Initiatives List</h3>
            </div>

              <div className='dbtableTop'>

                <div className='dbSearch'>
                  {/* <input type="search" placeholder='Search keyword' /> */}
                  {/* <i class="fa-solid fa-magnifying-glass"></i> */}
                </div>
                <div className='dbtableSrchbg'>
                  <button className='btn' onClick={onAddaAchievement}><i class="fa-solid fa-plus"></i> Add Achievement</button>
                </div>
              </div>
              <br></br>
              <div >
                <table>
                  <thead>
                    <tr>
                      <th>Name of the Initiative</th>
                      <th>Details of the Initiative</th>
                      <th>Created Date</th>
                      <th>Draft Status</th>
                      <th>Forward</th>
                      {userData?.USER_LEVEL === "GP" ? "" :
                        <th>Rating</th>}
                      {userData?.USER_LEVEL === "GP" ?
                        <th>Rating given by Block</th> : ""}
                      {userData?.USER_LEVEL === "GP" ?
                        <th>Remarks given by Block</th> : ""}
                      {userData?.USER_LEVEL === "GP" || userData?.USER_LEVEL === "BLOCK" ?
                        <th>Rating given by District</th> : ""}
                      {userData?.USER_LEVEL === "GP" || userData?.USER_LEVEL === "BLOCK" ?
                        <th>Remarks given by District</th> : ""}




                      {/* <th>Action</th> */}
                    </tr>
                  </thead>
                  {/* {industryList?.map((ind, index) => ( */}
                  <tbody>
                    {achievementList && achievementList?.list?.map((d, index) => (

                      <tr>
                        <td><Link to={`/AchievementView?id=${d?.INITIATIVE_ID}`}>{d?.INITIATIVE_NAME}</Link></td>
                        <td><Link to={`/achievement-details?id=${d?.INITIATIVE_ID}`}>{d?.DETAILS}</Link></td>
                        <td><Link to={`/achievement-details?id=${d?.INITIATIVE_ID}`}>{format(new Date(d?.CREATEDATE), 'dd-MM-yyyy')}</Link></td>
                        {
                          d?.IS_DRAFT ? <td><Link to={`/edit-achievement?id=${d?.INITIATIVE_ID}&evnt=${params.get('evnt')}=&evnt_index=${params.get('evnt_index')}&evnl=${params.get('evnl')}`}><i class="fa-duotone fa-circle-check fa-lg" style={{ color: "#18cd2d" }}></i></Link></td> : <td><i class="fa-regular fa-circle-xmark fa-lg" style={{ color: "#e70d0d" }}></i></td>
                        }
                        {userData?.USER_LEVEL === "GP" && d?.BLOCK_FORWARD == null && d?.IS_DRAFT == 0 ?

                          <td>
                            <button type="button"
                              className='btn'
                              onClick={() => onGpForward(d)}
                            >
                              <i class="fa-solid fa-forward"></i>
                            </button>
                          </td> :

                          userData?.USER_LEVEL === "BLOCK" && d?.DIST_FORWARD == 0 || d?.DIST_FORWARD == null && d?.IS_DRAFT == 0 ?

                            <td>
                              <button type="button"
                                className="btn float-left"
                                onClick={() => onBlockForward(d)}
                              >
                                <i class="fa-solid fa-forward"></i>
                              </button>
                            </td> :
                            userData?.USER_LEVEL === "DIST" ?
                              <td>
                                <button type="button"
                                  className="btn float-left"
                                  onClick={() => onDistForward(d)}
                                >
                                  <i class="fa-solid fa-forward"></i>
                                </button>
                              </td> :
                              <td>
                                <button type="button"
                                  className="btn float-left"

                                >
                                  <i>Forwarded</i>
                                </button>
                              </td>
                        }
                        {userData?.USER_LEVEL === "GP" ? "" :
                          <td>
                            <button type="button"
                              className="btn float-left"
                              onClick={() => onStar(d)}
                            ><i class="fa-solid fa-star"></i> </button>
                          </td>
                        }
                        {userData?.USER_LEVEL === "GP" ?
                          <td>{userData?.USER_LEVEL === "GP" && d?.BLOCK_RATING === null ? "Not yet given" : d?.BLOCK_RATING}</td>
                          : ""}

                        {userData?.USER_LEVEL === "BLOCK" ?
                          <td>{userData?.USER_LEVEL === "BLOCK" && d?.DIST_RATING === null ? "Not yet given" : d?.DIST_RATING}</td>
                          : ""}
                        {/* {userData?.USER_LEVEL === "DIST" ?
                          <td>{userData?.USER_LEVEL === "DIST" && d?.HQ_RATING === null ? "Not yet given" : d?.HQ_RATING}</td>
                          : ""} */}
                        {userData?.USER_LEVEL === "GP" ?
                          <td>{userData?.USER_LEVEL === "GP" && d?.BLOCK_REMARK === null ? "Not yet given" : d?.BLOCK_REMARK}</td>
                          : ""}
                        {userData?.USER_LEVEL === "GP" ?
                          <td>{userData?.USER_LEVEL === "GP" && d?.DIST_RATING === null ? "Not yet given" : d?.DIST_RATING}</td>
                          : ""}
                        {userData?.USER_LEVEL === "GP" ?
                          <td>{userData?.USER_LEVEL === "GP" && d?.DIST_REMARK === null ? "Not yet given" : d?.DIST_REMARK}</td>
                          : ""}
                        {userData?.USER_LEVEL === "BLOCK" ?
                          <td>{userData?.USER_LEVEL === "BLOCK" && d?.DIST_REMARK === null ? "Not yet given" : d?.DIST_REMARK}</td>
                          : ""}

                      </tr>
                    ))}


                  </tbody>
                  {/* ))} */}

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>


      <nav className="footer">
        <img src={footer} style={{ marginTop: "450px" }} />
        <p className="text-center lastp" style={{ fontSize: "16px !important" }}><strong>©</strong>
          2024 Designed and Developed By <b>IT And Statistical Cell,</b> Panchayat & Rural
          Development Department <b>Govt. of West Bengal</b>
        </p>
        <p className="text-center lastp" style={{ fontSize: "14px !important" }}>Site best viewed with 1920x1080 resolution in
          Google Chrome 31.0.1650.63, Firefox 55.0.2, Safari 5.1.7 & IE 11.0 and above</p>
      </nav>

    </div>

  )
}

export default AchievementList;