import React, { useState, useEffect, useContext } from 'react';
import '../../src/assets/css/style.css';
import footer from "../../src/assets/img/mainfooterbg.png"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { getSchemeList, getCategoryList, getThemeList, draftAchievement, postAchievement } from "../AchievementService"
import { Button, Modal } from 'react-bootstrap';
import defImg from "../assets/img/download.png"
import { Location } from './LocationContext';
import { useNavigate } from 'react-router-dom';
import { Link, useSearchParams } from 'react-router-dom';
import { getAchievementById } from '../AchievementService'
import stateStore from "../Achievement/Zustand";

const EditAchievement = () => {
  const { value, setValue, setValueImage } = stateStore();

  const location = useContext(Location)
  console.log(location, "location")
  const navigate = useNavigate();
  const [params] = useSearchParams();
  console.log(params.get('id'), "PARAMS")
  const handleCloseDelete = () => setShowDelete(false);
  const [showDelete, setShowDelete] = useState(false);
  const [getInitiative, setInitiative] = useState("");
  const [getDetailsOfInitiatives, setDetailsOfInitiatives] = useState("");
  const [getSpreadOfInitiative, setSpreadOfInitiatives] = useState("");
  const [getScheme, setScheme] = useState("");
  const [getCategory, setCategory] = useState("");
  const [getTheme, setTheme] = useState("");
  const [getUniqueOfInitiatives, setUniqueOfInitiatives] = useState("");
  const [getExecutionOfInitiatives, setExecutionOfInitiatives] = useState("");
  const [getImpactOfInitiatives, setImpactOfInitiatives] = useState("");
  const [getMojorChallenges, setMojorChallenges] = useState("");
  const [getSPRS, setSPRS] = useState("");
  const [getStakeholder, setStakeholder] = useState("");
  const [getWebsiteLink, setWebsiteLink] = useState("");
  const [getVideoLink, setVideoLink] = useState("");
  const [getAwardRecognotion, setAwardRecognotion] = useState("");
  const [getName, setName] = useState("");
  const [getDesignation, setDesignation] = useState("");
  const [getMobileNumber, setMobileNumber] = useState('');
  const [getEmail, setEmail] = useState("");
  const [getEmailInput, setEmailInput] = useState("");
  const [getSchemeDataList, setSchemeDataList] = useState([]);
  const [getCategoryDataList, setCategoryDataList] = useState([]);
  const [getThemeDataList, setThemeDataList] = useState([]);
  const [image, setImage] = useState({ preview: "", raw: "" });
  const [getImage, setGetImage] = useState(null);
  const [getImageresult, setGetImageresult] = useState("")

  const [image2, setImage2] = useState({ preview: "", raw: "" });
  const [getImage2, setGetImage2] = useState(null);
  const [getImageresult2, setGetImageresult2] = useState("")
  const [getAchievementId, setAchievementId] = useState({})
  const [integerValue, setIntegerValue] = useState(null);
  console.log(getImage, "getImage", getImage2, "getImage2")
  console.log(params.get('evnt_index'), "idididididid")
  const [allData, setAllData] = useState(
    {
      INITIATIVE_NAME: '',
      DETAILS: '',
      UNIQUE_DETAILS: '',
      EXECUTION_STEPS: '',
      IMPACT: '',
      CHALLENGES: '',
      SCALABILITY: '',
      STAKEHOLDER_DETAILS: '',
      WEBSITE: '',
      VIDEO: '',
      AWARDS: '',
      PROJECT_HEAD_NAME: '',
      DESIGNATION: '',
      MOBILE: '',
      EMAIL: '',
    }
  )

  useEffect(() => {
    convertToInteger();
  }, []);



  const convertToInteger = () => {
    // Decode the Base64 string
    const decodedString = atob(params.get('evnt_index'));
    // Parse the resulting string into an integer
    const integerValue = parseInt(decodedString, 10);
    // Update the state to reflect the converted value
    setIntegerValue(integerValue);

  };
  console.log(integerValue, "integerValue")

  const optionsData = [
    { label: 'State wide', value: 'S' },
    { label: 'District Level', value: 'D' },
    { label: 'Block', value: 'B' },
    { label: 'GP Level', value: 'GP' },
  ];

  console.log(allData, "allDataallData")
  useEffect(() => {
    getAllAchievementList()
  }, [])

  async function getAllAchievementList() {
    getAchievementById(params.get(`id`)).then(function (result) {
      const response = result?.data;
      console.log(response, "response")
      setAchievementId(response);
      setAllData(response)

    });
  }

  const onNameOfInitiative = (e) => {
    setInitiative({ ...allData, INITIATIVE_NAME: e.target.value })
    setAllData({ ...allData, INITIATIVE_NAME: e.target.value })

  }

  const onSelectInitiative = (e) => {
    setSpreadOfInitiatives(e.target.value)
  }

  const onScheme = (e) => {
    setScheme(e.target.value)
  }

  const onCategory = (e) => {
    setCategory(e.target.value)
  }

  const onTheme = (e) => {
    setTheme(e.target.value)
  }

  const onDeatilsOfInitiatives = (e) => {
    setDetailsOfInitiatives(e.target.value)
    setAllData({ ...allData, DETAILS: e.target.value })

  }

  const onUniqueFeaturesOfInitiatives = (e) => {
    setUniqueOfInitiatives(e.target.value)
    setAllData({ ...allData, UNIQUE_DETAILS: e.target.value })

  }

  const onExecutionOfInitiatives = (e) => {
    setExecutionOfInitiatives(e.target.value)
    setAllData({ ...allData, EXECUTION_STEPS: e.target.value })

  }

  const onImpactOfInitiatives = (e) => {
    setImpactOfInitiatives(e.target.value)
    setAllData({ ...allData, IMPACT: e.target.value })

  }

  const onMojorChallenges = (e) => {
    setMojorChallenges(e.target.value)
    setAllData({ ...allData, CHALLENGES: e.target.value })

  }

  const onSPRS = (e) => {
    setSPRS(e.target.value)
    setAllData({ ...allData, SCALABILITY: e.target.value })

  }

  const onStakeholder = (e) => {
    setStakeholder(e.target.value)
    setAllData({ ...allData, STAKEHOLDER_DETAILS: e.target.value })

  }

  const onWebsiteLink = (e) => {
    setWebsiteLink(e.target.value)
    setAllData({ ...allData, WEBSITE: e.target.value })

  }

  const onVideoLink = (e) => {
    setVideoLink(e.target.value)
    setAllData({ ...allData, VIDEO: e.target.value })

  }

  const onAwardRecognotion = (e) => {
    setAwardRecognotion(e.target.value)
    setAllData({ ...allData, AWARDS: e.target.value })

  }

  const onName = (e) => {
    setName(e.target.value)
    setAllData({ ...allData, PROJECT_HEAD_NAME: e.target.value })

  }

  const onDesignation = (e) => {
    setDesignation(e.target.value)
    setAllData({ ...allData, DESIGNATION: e.target.value })

  }

  const onMobile = (e) => {
    setMobileNumber(e.target.value)
    setAllData({ ...allData, MOBILE: e.target.value })

  }

  const onEmail = (e) => {
    setEmailInput(e.target.value)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    setEmail(emailRegex.test(e.target.value));
    setAllData({ ...allData, EMAIL: emailRegex.test(e.target.value) })

  }
  console.log(allData?.INITIATIVE_NAME, getInitiative, "allData?.INITIATIVE_NAME")
  const onDraft = () => {
    if (allData?.INITIATIVE_NAME === "") {
      toast.error("Please enter name of the Initiative")
    } else if (allData?.INITIATIVE_NAME.length > 50) {
      toast.error("Name of the Initiative max size 50 words")
    } else if (allData?.DETAILS === "") {
      toast.error("Please enter details of Initiative")
    } else if (allData?.DETAILS.length > 350) {
      toast.error("Details of Initiative max size 350 words")
    } else if (allData?.UNIQUE_DETAILS === "") {
      toast.error("Please enter unique features of the Initiative")
    } else if (allData?.UNIQUE_DETAILS.lenth > 250) {
      toast.error("unique features of the Initiative max size 250 words")
    } else if (allData?.EXECUTION_STEPS === "") {
      toast.error("Please enter Steps involved in the execution of the initiative")
    } else if (allData?.EXECUTION_STEPS.length > 200) {
      toast.error("Steps involved in the execution of the initiative max size 200 words")
    } else if (allData?.IMPACT === "") {
      toast.error("Please enter Impact of the initiative")
    } else if (allData?.IMPACT.length > 250) {
      toast.error("Impact of the initiative max size 250 words")
    } else if (allData?.CHALLENGES === "") {
      toast.error("Please enter Major challenges faced")
    } else if (allData?.CHALLENGES.length > 150) {
      toast.error("Major challenges faced max size 150 words")
    } else if (allData?.SCALABILITY === "") {
      toast.error("Please enter initiative is scalable, portable, replicable and sustainable")
    } else if (allData?.SCALABILITY.length > 350) {
      toast.error("initiative is scalable, portable, replicable and sustainable max size 350 words")
    } else if (allData?.STAKEHOLDER_DETAILS === "") {
      toast.error("Please enter the stakeholder details")
    } else if (allData?.STAKEHOLDER_DETAILS.length > 150) {
      toast.error("Stakeholder details max size 150 words")
    } else if (allData?.PROJECT_HEAD_NAME === "") {
      toast.error("Please enter project head name")
    } else if (allData?.DESIGNATION === "") {
      toast.error("Please enter project head designation")
    } else if (allData?.MOBILE.length != 10) {
      toast.error("Please enter 10 digit mobile number")
    } else if (allData?.EMAIL === "") {
      toast.error("Please enter project head email id")
    } else if (!allData?.EMAIL) {
      toast.error("Please enter valid email id")
    } else {
      let formData = new FormData();
      formData.append('initiativeName', allData?.INITIATIVE_NAME);
      formData.append('initiativeSpread', getSpreadOfInitiative ? getSpreadOfInitiative : optionsData.find(c => c.value === getAchievementId?.INITIATIVE_SPREAD)?.label);
      formData.append('schemeId', getScheme ? getScheme : getSchemeDataList.find(c => c.schemeId === getAchievementId?.SCHEME_ID)?.schemeName);
      formData.append('categoryId', getCategory ? getCategory : getCategoryDataList.find(c => c.categoryId === getAchievementId?.CATEGORY_ID)?.categoryName);
      formData.append('themeId', getTheme ? getTheme : getThemeDataList.find(c => c.themeId === getAchievementId?.THEME_ID)?.themeName);
      formData.append('details', allData?.DETAILS);
      formData.append('uniqueDetails', allData?.UNIQUE_DETAILS);
      formData.append('executionSteps', allData?.EXECUTION_STEPS);
      formData.append('impact', allData?.IMPACT);
      formData.append('challenges', allData?.CHALLENGES);
      formData.append('scalability', allData?.SCALABILITY);
      formData.append('stakeholderDetails', allData?.STAKEHOLDER_DETAILS);
      formData.append('website', allData?.WEBSITE);
      formData.append('video', allData?.VIDEO);
      formData.append('image', getImage ? getImage : allData?.image);
      formData.append('image2', getImage2 ? getImage2 : allData?.image2);
      formData.append('awards', allData?.AWARDS);
      formData.append('name', allData?.PROJECT_HEAD_NAME);
      formData.append('designation', allData?.DESIGNATION);
      formData.append('mobile', allData?.MOBILE);
      formData.append('email', getEmailInput?getEmailInput:allData?.EMAIL);
      formData.append('isDraft', 1);
      formData.append('userIndex', integerValue);



      postAchievement(
        formData,
        (res) => {
          console.log(res, "status101")
          if (res.success === true) {

            navigate(`/${location.search}`)
            toast.success(res.message)

          } else {
            console.log("nononononono")
            toast.error(res.message)

          }
        }
      )
    }

  }
  console.log(getScheme, getCategory, getTheme, "chekh")

  console.log(allData, "allDataallDataallData")
  const onSubmit = () => {
    if (allData?.INITIATIVE_NAME === "") {
      toast.error("Please enter name of the Initiative")
    } else if (allData?.INITIATIVE_NAME.length > 50) {
      toast.error("Name of the Initiative max size 50 words")
    } else if (allData?.DETAILS === "") {
      toast.error("Please enter details of Initiative")
    } else if (allData?.DETAILS.length > 350) {
      toast.error("Details of Initiative max size 350 words")
    } else if (allData?.UNIQUE_DETAILS === "") {
      toast.error("Please enter unique features of the Initiative")
    } else if (allData?.UNIQUE_DETAILS.length > 250) {
      toast.error("unique features of the Initiative max size 250 words")
    } else if (allData?.EXECUTION_STEPS === "") {
      toast.error("Please enter Steps involved in the execution of the initiative")
    } else if (allData?.EXECUTION_STEPS.length > 200) {
      toast.error("Steps involved in the execution of the initiative max size 200 words")
    } else if (allData?.IMPACT === "") {
      toast.error("Please enter Impact of the initiative")
    } else if (allData?.IMPACT.length > 250) {
      toast.error("Impact of the initiative max size 250 words")
    } else if (allData?.CHALLENGES === "") {
      toast.error("Please enter Major challenges faced")
    } else if (allData?.CHALLENGES.length > 150) {
      toast.error("Major challenges faced max size 150 words")
    } else if (allData?.SCALABILITY === "") {
      toast.error("Please enter initiative is scalable, portable, replicable and sustainable")
    } else if (allData?.SCALABILITY.length > 350) {
      toast.error("initiative is scalable, portable, replicable and sustainable max size 350 words")
    } else if (allData?.STAKEHOLDER_DETAILS === "") {
      toast.error("Please enter the stakeholder details")
    } else if (allData?.STAKEHOLDER_DETAILS.length > 150) {
      toast.error("Stakeholder details max size 150 words")
    } else if (allData?.PROJECT_HEAD_NAME === "") {
      toast.error("Please enter project head name")
    } else if (allData?.DESIGNATION === "") {
      toast.error("Please enter project head designation")
    } else if (allData?.MOBILE.length != 10) {
      toast.error("Please enter 10 digit mobile number")
    } else if (allData?.EMAIL === "") {
      toast.error("Please enter project head email id")
    } else if (!getEmail) {
      toast.error("Please enter valid email id")
    } else {
      let formData = new FormData();
      formData.append('initiativeName', allData?.INITIATIVE_NAME ? allData?.INITIATIVE_NAME : value.getInitiative);
      formData.append('initiativeSpread', allData?.INITIATIVE_ID ? allData?.INITIATIVE_ID : value.getSpreadOfInitiative);
      formData.append('schemeId', allData?.SCHEME_ID ? allData?.SCHEME_ID : value.getScheme);
      formData.append('categoryId', allData?.CATEGORY_ID ? allData?.CATEGORY_ID : value.getCategory);
      formData.append('themeId', allData?.SCHEME_ID ? allData?.SCHEME_ID : value.getTheme);
      formData.append('details', allData?.DETAILS ? allData?.DETAILS : value.getDetailsOfInitiatives);
      formData.append('uniqueDetails', allData?.UNIQUE_DETAILS ? allData?.UNIQUE_DETAILS : value.getUniqueOfInitiatives);
      formData.append('executionSteps', allData?.EXECUTION_STEPS ? allData?.EXECUTION_STEPS : value.getExecutionOfInitiatives);
      formData.append('impact', allData?.IMPACT ? allData?.IMPACT : value.getImpactOfInitiatives);
      formData.append('challenges', allData?.CHALLENGES ? allData?.CHALLENGES : value.getMojorChallenges);
      formData.append('scalability', allData?.SCALABILITY ? allData?.SCALABILITY : value.getSPRS);
      formData.append('stakeholderDetails', allData?.STAKEHOLDER_DETAILS ? allData?.STAKEHOLDER_DETAILS : value.getStakeholder);
      formData.append('website', allData?.WEBSITE ? allData?.WEBSITE : value.getWebsiteLink);
      formData.append('video', allData?.VIDEO ? allData?.VIDEO : value.getVideoLink);
      formData.append('image', getImage ? getImage : allData?.image);
      formData.append('image2', getImage2 ? getImage2 : allData?.image2);
      formData.append('awards', allData?.AWARDS ? allData?.AWARDS : value.getAwardRecognotion);
      formData.append('name', allData?.PROJECT_HEAD_NAME ? allData?.PROJECT_HEAD_NAME : value.getName);
      formData.append('designation', allData?.DESIGNATION ? allData?.DESIGNATION : value.getDesignation);
      formData.append('mobile', allData?.MOBILE ? allData?.MOBILE : value.getMobileNumber);
      formData.append('email', allData?.EMAIL ? allData?.EMAIL : value.getEmail);
      formData.append('isDraft', 0);
      formData.append('userIndex', integerValue);



      postAchievement(
        formData,
        (res) => {
          console.log(res, "status101")
          if (res.success === true) {

            navigate(`/${location.search}`)
            toast.success(res.message)

          } else {
            console.log("nononononono")
            toast.error(res.message)

          }
        }
      )
    }
  }

  //scheme data fetching
  //category data fetching
  //theme data fetching

  useEffect(() => {
    getSchemeListData();
    getCategoryListData();
    getThemeListData();
  }, []);

  async function getSchemeListData() {
    getSchemeList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setSchemeDataList(response);
    });
  }

  async function getCategoryListData() {
    getCategoryList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setCategoryDataList(response);
    });
  }

  async function getThemeListData() {
    getThemeList().then(function (result) {
      const response = result?.data;
      console.log(response, "resresres")
      setThemeDataList(response);
    });
  }


  //image proccessing
  const onFile = (event) => {
    console.log(event.target.files[0], "filee")
    if (event["target"].files.length > 0) {
      const file = event["target"].files[0];
      // setUserData({...userData, profileImage : file});
      setImage({
        preview: URL.createObjectURL(event.target.files[0]),
        raw: event.target.files[0]
      });
      console.log(image, "101823")
      setGetImage(file)
      setGetImageresult(file.name)
      //     const reader = new FileReader();
      //     reader.readAsDataURL(file);
      //     reader.onload = (event) => {
      //         setGetImageresult(reader.result);
      //   };
    }

  }
  //image proccessing for second input
  const onFile2 = (event) => {
    console.log(event.target.files[0], "filee")
    if (event["target"].files.length > 0) {
      const file = event["target"].files[0];
      // setUserData({...userData, profileImage : file});
      setImage2({
        preview: URL.createObjectURL(event.target.files[0]),
        raw: event.target.files[0]
      });
      console.log(image, "101823")
      setGetImage2(file)
      setGetImageresult2(file.name)
      //     const reader = new FileReader();
      //     reader.readAsDataURL(file);
      //     reader.onload = (event) => {
      //         setGetImageresult(reader.result);
      //   };
    }

  }



  return (
    <div>
      <ToastContainer />
      {/* <div className="navbar ">
        <div className="wrapper">
          <div
            className="title-bar"
            data-responsive-toggle="example-animated-menu"
            data-hide-for="medium"
          >
            <button className="menu-icon" type="button" data-toggle="" />
            <div className="title-bar-title">Menu</div>

          </div>
          <div
            className="title-bar"
            id="example-animated-menu"
            data-animate="hinge-in-from-top fade-out"
          >
            <div className="title-bar-left">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="index.html">
                    <i className="fa fa-home" aria-hidden="true" />
                    Home
                  </a>
                </li>
                <li>
                  <a href="form.html">About Us</a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-line-chart" aria-hidden="true" />
                    Analytics
                  </a>
                </li>
                <li>
                  <a href="#">Reports</a>
                </li>
                <li>
                  <a href="#">Initiatives</a>
                </li>
              </ul>
            </div>
            <div className="title-bar-right">
              <ul
                className="vertical medium-horizontal menu"
                data-responsive-menu="drilldown medium-dropdown"
              >
                <li>
                  <a href="login.html" className="btn float-right">
                    Login (Registered User)
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div> */}


      <div className="grid-container mn_ht">
        <div className="grid-x grid-margin-x">
          <form data-abide="" noValidate="">
            <div className="grid-x grid-margin-x">
              <div className="cell">
                <div
                  data-abide-error=""
                  className="alert callout"
                  style={{ display: "none" }}
                >
                  <p>
                    <i className="fi-alert" /> There are some errors in your form.
                  </p>
                </div>
              </div>
            </div>
            <div>
              <h3 style={{ marginLeft: 400, marginTop: 20 }}>Achievement/Initiatives Form</h3>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Name of the Initiative&nbsp;(Max 50 Words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.INITIATIVE_NAME}
                    onChange={onNameOfInitiative}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell medium-3">
                <label>
                  <b>
                    Spread of the Initiative<span style={{ color: "red" }}> *</span>
                  </b>
                </label>
                <select id="select" required="" onChange={onSelectInitiative}>
                  <option selected hidden disabled>
                    {getSpreadOfInitiative ? getSpreadOfInitiative : optionsData.find(c => c.value === getAchievementId?.INITIATIVE_SPREAD)?.label}
                  </option>
                  {optionsData.map(option => (
                    <option value={option.value}>{option.label}</option>
                  ))}

                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Scheme<span style={{ color: "red" }}> *</span></b>
                </label>
                <select id="select" required="" onChange={onScheme}>
                  <option selected hidden disabled>
                    {getScheme ? getScheme : getSchemeDataList.find(c => c.schemeId === getAchievementId?.SCHEME_ID)?.schemeName}
                  </option>
                  {getSchemeDataList?.map((d) => (
                    <option value={d?.schemeId}>{d?.schemeName}</option>

                  ))}
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Category<span style={{ color: "red" }}> *</span></b>
                </label>
                <select id="select" required="" onChange={onCategory}>
                  <option selected hidden disabled>
                    {getCategory ? getCategory : getCategoryDataList.find(c => c.categoryId === getAchievementId?.CATEGORY_ID)?.categoryName}
                  </option>
                  {getCategoryDataList?.map((d) => (
                    <option value={d?.categoryId}>{d?.categoryName}</option>

                  ))}
                </select>
              </div>
              <div className="cell medium-3">
                <label>
                  <b>Theme<span style={{ color: "red" }}> *</span></b>
                </label>
                <select id="select" required="" onChange={onTheme}>
                  <option selected hidden disabled>
                    {getTheme ? getTheme : getThemeDataList.find(c => c.themeId === getAchievementId?.THEME_ID)?.themeName}
                  </option>
                  {getThemeDataList?.map((d) => (
                    <option value={d?.themeId}>{d?.themeName}</option>

                  ))}
                </select>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Details of Initiative&nbsp;(Max 350 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.DETAILS}
                    onChange={onDeatilsOfInitiatives}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Unique features of the initiative&nbsp;(Max 250 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.UNIQUE_DETAILS}
                    onChange={onUniqueFeaturesOfInitiatives}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Steps involved in the execution of the initiative&nbsp;(Max 200
                    words)<span style={{ color: "red" }}>*</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.EXECUTION_STEPS}

                    onChange={onExecutionOfInitiatives}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Impact of the initiative?&nbsp;(Max 250 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.IMPACT}

                    onChange={onImpactOfInitiatives}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Major challenges faced and overcome the challenges during the
                    project execution.&nbsp;(Max 150 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.CHALLENGES}

                    onChange={onMojorChallenges}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Is the initiative is scalable, portable, replicable and
                    sustainable?&nbsp;(Max 350 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.SCALABILITY}

                    onChange={onSPRS}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Please enter the stakeholder details.&nbsp;(Max 150 words)
                    <span style={{ color: "red" }}> *</span>
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.STAKEHOLDER_DETAILS}

                    onChange={onStakeholder}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-6">
                <label>
                  <b>Website Link</b>
                  <input
                    type="text"
                    placeholder="Website Link"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={onWebsiteLink}
                    defaultValue={allData?.WEBSITE}


                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>Video Link</b>
                  <input
                    type="text"
                    placeholder="Video Link"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={onVideoLink}
                    defaultValue={allData?.VIDEO}

                  />
                </label>
              </div>
            </div>
            <br></br>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label className="form-label" htmlFor="customFile">
                  <b>
                    Upload photos of the initiative.&nbsp;(Supported file formats
                    .jpeg .png, Max File Size : 2MB )
                    <span style={{ color: "red" }}> *</span>
                  </b>
                </label>
              </div>

              <div className="cell small-4">
                <input type="file" className="form-control" id="customFile" accept="image/png, image/jpeg" onChange={onFile} />

              </div>

              <div className="cell small-2">
                <img src={image.preview ? image.preview : `http://wbpms.in:8085/uploads/${allData?.image}`} width="100" height="0" />


              </div>
              <div className="cell small-4">
                <input type="file" className="form-control" id="customFile" accept="image/png, image/jpeg" onChange={onFile2} />

              </div>

              <div className="cell small-2">
                <img src={image2.preview ? image2.preview : `http://wbpms.in:8085/uploads/${allData?.image2}`} width="100" height="0" />

              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <label>
                  <b>
                    Awards Recognition / Any other details&nbsp;(Name of Award and
                    Award Conferring Authority)&nbsp;(Max 150 words)
                  </b>
                  <textarea
                    // className="form-control"
                    id="exampleFormControlTextarea1"
                    rows={3}
                    defaultValue={allData?.AWARDS}

                    onChange={onAwardRecognotion}
                    style={{ resize: 'none' }}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">
              <div className="cell small-12">
                <h5>
                  Contact details of the Project Head
                  <span style={{ color: "red" }}> *</span>
                </h5>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Name<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your name"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={onName}
                    defaultValue={allData?.PROJECT_HEAD_NAME}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Designation<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your designation"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={onDesignation}
                    defaultValue={allData?.DESIGNATION}
                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Mobile Number<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="number"
                    placeholder="Enter your mobile number"
                    aria-describedby="exampleHelpTextNumber"
                    onChange={onMobile}
                    defaultValue={allData?.MOBILE}

                  />
                </label>
              </div>
              <div className="cell small-6">
                <label>
                  <b>
                    Email id<span style={{ color: "red" }}> *</span>
                  </b>
                  <input
                    type="text"
                    placeholder="Enter your email id"
                    aria-describedby="exampleHelpTextNumber"
                    required=""
                    pattern="number"
                    onChange={onEmail}
                    defaultValue={allData?.EMAIL}

                  />
                </label>
              </div>
            </div>
            <div className="grid-x grid-margin-x">


              <div className="cell small-11">
                <button
                  type="button"
                  className="btn float-left"
                  style={{ marginLeft: "1000px", marginTop: "10px" }}
                  onClick={onDraft}

                >
                  Draft
                </button>
              </div>
              <div className="cell small-1">
                <button
                  type="button"
                  className="btn float-left"
                  style={{ marginLeft: "-10px", marginTop: "10px" }}
                  onClick={onSubmit}
                >
                  Submit
                </button>
              </div>
            </div>

          </form>
        </div>
      </div>


      <nav className="footer">
        <img src={footer} />
        <p className="text-center lastp" style={{ fontSize: "16px !important" }}><strong>©</strong>
          2024 Designed and Developed By <b>IT And Statistical Cell,</b> Panchayat & Rural
          Development Department <b>Govt. of West Bengal</b>
        </p>
        <p className="text-center lastp" style={{ fontSize: "14px !important" }}>Site best viewed with 1920x1080 resolution in
          Google Chrome 31.0.1650.63, Firefox 55.0.2, Safari 5.1.7 & IE 11.0 and above</p>
      </nav>
      {/* <Modal show={showDelete} onHide={handleCloseDelete}>
        <Modal.Header closeButton>
          <Modal.Title>Are you sure to delete ?</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;

        </Modal.Body>
      </Modal> */}
    </div>
  )
}

export default EditAchievement;